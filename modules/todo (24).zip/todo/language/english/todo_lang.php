<?php

$lang['My task'] = 'My task';
$lang['Team-task'] = 'Team-task';
$lang['Assign Team-task'] = 'Assign Team-task';
$lang['Settings'] = 'Settings';

$lang['My To Do'] = 'My To Do';
$lang['My Team To Do'] = 'My Team To Do';
$lang['Submit My Today\'s Plan'] = 'Submit My Today\'s Plan';
$lang['Due Today'] = 'Due Today';
$lang['Due Next 5 Days'] = 'Due Next 5 Days';
$lang['Due Next 25 Days'] = 'Due Next 25 Days';
$lang['Already Overdue'] = 'Already Overdue';
$lang['Needs Attention'] = 'Needs Attention';
$lang['Today\'s To Do Plan of'] = 'Today\'s To Do Plan of';
$lang['Plan saved successfully'] = 'Plan saved successfully';
$lang['Error saving plan'] = 'Error saving plan';
$lang['No tasks found'] = 'No tasks found';




