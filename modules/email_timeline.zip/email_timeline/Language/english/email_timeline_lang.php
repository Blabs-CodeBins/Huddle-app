<?php

$lang['email_timeline'] = 'Email Timeline';
$lang['emails'] = 'Emails';
$lang['threads'] = 'Threads';
$lang['employees'] = 'Employees';
$lang['subject'] = 'Subject';
$lang['message'] = 'Message';
$lang['type'] = 'Type';
$lang['received'] = 'Received';
$lang['sent'] = 'Sent';
$lang['created_at'] = 'Created At';
$lang['full_name'] = 'Full Name';
$lang['company'] = 'Company';
$lang['reply'] = 'Reply';
$lang['send'] = 'Send';
$lang['send_email'] = 'Send Email';
$lang['retrieve_email'] = 'Retrieve Email';
