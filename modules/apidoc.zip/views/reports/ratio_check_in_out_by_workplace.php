<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="relative ratio_check_in_out_by_workplace"class="hide reports_fr">
   <div id="ratio_check_in_out_by_workplace" class="reports"></div>
</div>